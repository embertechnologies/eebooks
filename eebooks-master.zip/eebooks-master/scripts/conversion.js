//Conversion doc:
// - imports Node.Js
// - Converts passes html from Firepad
//   to the server.
// - Returns PDF file